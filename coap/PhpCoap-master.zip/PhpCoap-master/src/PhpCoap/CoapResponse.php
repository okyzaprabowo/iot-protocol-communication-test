<?php

namespace PhpCoap;

class CoapResponse extends CoapPdu
{
	function __construct()
	{
		parent::__construct();
	}
}